//
//  omerv3Tests.swift
//  omerv3Tests
//
//  Created by עומר זנו on 21/11/2025.
//

import Testing
@testable import omerv3

struct omerv3Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
