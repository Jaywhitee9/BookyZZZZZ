# 📱 **תוכנית מלאה: מערכת CMS ואפליקציית ניהול**

## 🎯 **מטרה**
בניית מערכת מלאה שמאפשרת לבעלי עסקים (ספרים/מעצבי שיער) לנהל את כל האפליקציה דרך אפליקציית ניהול נפרדת, ללא צורך בקוד.

---

## 🏗️ **ארכיטקטורת המערכת**

```
┌─────────────────────────────────────────────────────────────┐
│                     אפליקציית לקוח                          │
│                    (omerv3 - iOS)                            │
│                                                               │
│  • הזמנת תורים                                                │
│  • צפייה בסטוריז                                             │
│  • התורים שלי                                                 │
│  • פרופיל                                                     │
└───────────────────┬─────────────────────────────────────────┘
                    │
                    │ API Calls
                    │
┌───────────────────▼─────────────────────────────────────────┐
│                   Backend Server                             │
│                  (Firebase / Node.js)                        │
│                                                               │
│  • REST API / GraphQL                                        │
│  • Authentication (JWT)                                      │
│  • Database (Firestore / PostgreSQL)                         │
│  • File Storage (Firebase Storage / S3)                      │
│  • Push Notifications                                        │
└───────────────────┬─────────────────────────────────────────┘
                    │
                    │ API Calls
                    │
┌───────────────────▼─────────────────────────────────────────┐
│                אפליקציית ניהול                              │
│                (Admin App - iOS/Web)                         │
│                                                               │
│  • ניהול ספרים                                                │
│  • העלאת סטוריז                                              │
│  • ניהול שירותים                                              │
│  • קבלת הזמנות                                                │
│  • הגדרות עיצוב                                               │
└─────────────────────────────────────────────────────────────┘
```

---

## 📦 **Phase 1: תשתית Backend (חובה)**

### אופציה A: Firebase (מומלץ להתחלה)
**יתרונות:**
- ✅ מהיר להקמה
- ✅ Authentication מובנה
- ✅ Realtime Database
- ✅ Storage לתמונות/וידאו
- ✅ Push Notifications
- ✅ חינמי עד סקייל מסוים

**מה צריך:**
```bash
# 1. התקנת Firebase SDK
pod 'Firebase/Auth'
pod 'Firebase/Firestore'
pod 'Firebase/Storage'
pod 'Firebase/Messaging'

# 2. מבנה Database (Firestore Collections):
businesses/
  {businessId}/
    - settings (BusinessSettings)
    - staff/
      {staffId} (Staff)
      - stories/
        {storyId} (Story)
    - services/
      {serviceId} (Service)
    - appointments/
      {appointmentId} (Appointment)
    - customers/
      {customerId} (Customer)
```

### אופציה B: Backend מותאם (Node.js + PostgreSQL)
**יתרונות:**
- ✅ שליטה מלאה
- ✅ גמישות גבוהה
- ✅ עלויות נמוכות בסקייל גבוה

**Stack מומלץ:**
```
- Backend: Node.js + Express
- Database: PostgreSQL / MongoDB
- Storage: AWS S3 / Cloudinary
- Auth: JWT + bcrypt
- Deploy: Railway / Render / DigitalOcean
```

---

## 📱 **Phase 2: אפליקציית ניהול**

### תכונות מרכזיות:

#### 1️⃣ **ניהול סטוריז** (הפיצ'ר שביקשת)
```swift
StoryUploadView:
  - בחירת תמונה/וידאו מהגלריה
  - צילום תמונה/וידאו ישיר
  - הוספת טקסט/מדבקות
  - תצוגה מקדימה
  - העלאה לשרת
  - מחיקת סטוריז ישנים
```

**Flow:**
```
1. ספר נכנס לאפליקציית ניהול
2. לוחץ על "העלה סטורי חדש"
3. בוחר תמונה/וידאו
4. מוסיף טקסט (אופציונלי)
5. לוחץ "פרסם"
6. הסטורי מופיע באפליקציית הלקוח תוך שניות
```

#### 2️⃣ **ניהול תורים**
```
- רשימת תורים מתוזמנים
- אישור/ביטול תורים
- שינוי זמנים
- התראות לספרים
- סטטיסטיקות
```

#### 3️⃣ **ניהול שירותים**
```
- הוספה/עריכה/מחיקה של שירותים
- עדכון מחירים
- שינוי זמני טיפול
- הוספת תיאורים
```

#### 4️⃣ **ניהול עיצוב**
```
- החלפת תמונת Hero
- עדכון לוגו
- שינוי צבעי ערכה
- עריכת טקסטים
- שינוי שעות פעילות
```

#### 5️⃣ **ניהול ספרים**
```
- הוספת ספר חדש
- עריכת פרטי ספר
- לינקים לרשתות חברתיות
- זמינות וחופשות
```

---

## 🎨 **Phase 3: מסכים באפליקציית ניהול**

### מסך 1: Dashboard
```
┌─────────────────────────────┐
│  📊 Dashboard                │
├─────────────────────────────┤
│                              │
│  📅 תורים היום: 12           │
│  ⏰ תור הבא: 14:30           │
│  💰 הכנסות חודש: ₪4,500      │
│                              │
│  [תורים] [סטוריז] [הגדרות]  │
└─────────────────────────────┘
```

### מסך 2: העלאת סטוריז
```
┌─────────────────────────────┐
│  📸 סטורי חדש                │
├─────────────────────────────┤
│                              │
│  ┌─────────────────────┐    │
│  │                     │    │
│  │   [תצוגה מקדימה]    │    │
│  │                     │    │
│  └─────────────────────┘    │
│                              │
│  📝 הוסף טקסט...             │
│                              │
│  [📷 צלם] [🖼️ גלריה]        │
│  [🎬 וידאו] [פרסם ✅]         │
└─────────────────────────────┘
```

### מסך 3: ניהול תורים
```
┌─────────────────────────────┐
│  📆 תורים מתוזמנים           │
├─────────────────────────────┤
│                              │
│  🟢 14:00 - עומר ז.          │
│      תספורת (₪80)            │
│      [✓ אשר] [✗ בטל]        │
│                              │
│  🟡 15:30 - דני כ.           │
│      תספורת וזקן (₪90)       │
│      [✓ אשר] [✗ בטל]        │
│                              │
│  + הוסף תור ידני              │
└─────────────────────────────┘
```

---

## 🛠️ **Phase 4: תוכנית מימוש מפורטת**

### שלב 1: הקמת Backend (שבוע 1-2)
- [ ] בחירת פלטפורמה (Firebase / Custom)
- [ ] הקמת פרויקט
- [ ] יצירת מבנה Database
- [ ] יצירת API Endpoints:
  - `GET /api/business/{id}` - קבלת הגדרות עסק
  - `GET /api/staff` - קבלת רשימת ספרים + סטוריז
  - `POST /api/stories` - העלאת סטורי חדש
  - `GET /api/appointments` - קבלת תורים
  - `POST /api/appointments` - יצירת תור
  - `PUT /api/appointments/{id}` - עדכון תור
  - `DELETE /api/stories/{id}` - מחיקת סטורי
- [ ] Authentication למשתמשים
- [ ] File Upload לתמונות/וידאו

### שלב 2: עדכון אפליקציית הלקוח (שבוע 3)
- [ ] יצירת NetworkManager / Firebase Service
- [ ] החלפת Mock Data ב-API Calls
- [ ] Realtime Updates לסטוריז חדשים
- [ ] Cache תמונות
- [ ] Error Handling

### שלב 3: בניית אפליקציית ניהול (שבוע 4-6)
- [ ] יצירת פרויקט חדש
- [ ] מסך Login
- [ ] Dashboard
- [ ] העלאת סטוריז
- [ ] ניהול תורים
- [ ] ניהול שירותים
- [ ] הגדרות עיצוב
- [ ] Push Notifications

### שלב 4: Testing & Launch (שבוע 7-8)
- [ ] בדיקות E2E
- [ ] אופטימיזציה
- [ ] TestFlight / Beta
- [ ] Launch! 🚀

---

## 💻 **דוגמת קוד: API Integration**

### NetworkManager.swift (לאפליקציית הלקוח)
```swift
class NetworkManager {
    static let shared = NetworkManager()
    private let baseURL = "https://your-api.com/api"
    
    func fetchStaffWithStories(completion: @escaping ([Staff]) -> Void) {
        guard let url = URL(string: "\\(baseURL)/staff") else { return }
        
        URLSession.shared.dataTask(with: url) { data, response, error in
            guard let data = data else { return }
            
            if let staff = try? JSONDecoder().decode([Staff].self, from: data) {
                DispatchQueue.main.async {
                    completion(staff)
                }
            }
        }.resume()
    }
    
    func uploadStory(staffId: Int, image: UIImage, caption: String?, completion: @escaping (Bool) -> Void) {
        // Upload image to storage
        // Create Story object
        // POST to API
    }
}
```

### אינטגרציה ב-BookingViewModel:
```swift
func loadStaffFromServer() {
    NetworkManager.shared.fetchStaffWithStories { [weak self] staff in
        self?.staffMembers = staff
    }
}
```

---

## 🎯 **סיכום והמלצות**

### מה עשינו עכשיו:
✅ יצרנו מודל Story מלא
✅ בנינו קומפוננטת Stories עם UI מתקדם
✅ החלפנו את הקרוסלה הרגילה ב-Stories
✅ הוספנו סטוריז דמו

### הצעדים הבאים:
1. **להחליט על Backend** - Firebase או Custom?
2. **לבנות Backend** - API + Database + Storage
3. **לעדכן אפליקציית הלקוח** - להתחבר ל-API
4. **לבנות אפליקציית ניהול** - כל הניהול במקום אחד

### זמן משוער:
- **Backend**: 1-2 שבועות
- **עדכון אפליקציה קיימת**: 1 שבוע
- **אפליקציית ניהול**: 3-4 שבועות
- **סה"כ**: ~6-8 שבועות לפרויקט מלא

---

## 🤔 **רוצה שאתחיל לבנות משהו?**

אני יכול לעזור לך:
1. **להקים Firebase** ולעשות אינטגרציה ראשונית
2. **לבנות Backend Node.js** מאפס
3. **ליצור את אפליקציית הניהול**
4. **לעשות אינטגרציה מלאה**

ספר לי מה הכיוון שאתה רוצה לקחת! 🚀
