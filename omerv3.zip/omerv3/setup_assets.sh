#!/bin/bash

# Base path for assets
ASSETS_DIR="omerv3/Assets.xcassets"
SOURCE_DIR="barbershop-booking"

# Function to create image asset
create_asset() {
    NAME=$1
    FILENAME=$2
    
    # Create directory
    mkdir -p "$ASSETS_DIR/$NAME.imageset"
    
    # Copy file
    cp "$SOURCE_DIR/$FILENAME" "$ASSETS_DIR/$NAME.imageset/$FILENAME"
    
    # Create Contents.json
    cat > "$ASSETS_DIR/$NAME.imageset/Contents.json" << EOF
{
  "images" : [
    {
      "filename" : "$FILENAME",
      "idiom" : "universal",
      "scale" : "1x"
    },
    {
      "idiom" : "universal",
      "scale" : "2x"
    },
    {
      "idiom" : "universal",
      "scale" : "3x"
    }
  ],
  "info" : {
    "author" : "xcode",
    "version" : 1
  }
}
EOF
}

# Create assets
create_asset "hero" "hero.png"
create_asset "barber1" "barber1.png"
create_asset "barber2" "barber2.png"
create_asset "barber3" "barber3.png"
create_asset "barber4" "barber4.png"
create_asset "barber5" "barber5.png"

echo "Assets created successfully"
