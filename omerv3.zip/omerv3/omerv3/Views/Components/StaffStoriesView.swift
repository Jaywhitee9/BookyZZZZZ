import SwiftUI

// MARK: - Staff Stories Carousel (במקום הקרוסלה הרגילה)

struct StaffStoriesCarousel: View {
    @ObservedObject var viewModel: BookingViewModel
    @Binding var showBookingFlow: Bool
    @Binding var animateCarousel: Bool
    @State private var selectedStaff: Staff?
    @State private var showStoryViewer = false
    
    var body: some View {
        VStack(alignment: .trailing, spacing: 12) {
            // כותרת
            Text("עדכונים מהצוות")
                .font(.system(size: 16, weight: .semibold))
                .foregroundColor(.black.opacity(0.8))
                .padding(.horizontal, 20)
            
            // סקרול אופקי של הספרים
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 18) {
                    ForEach(viewModel.staffMembers) { staff in
                        StoryCircle(
                            staff: staff,
                            onTap: {
                                selectedStaff = staff
                                if hasValidStories(staff) {
                                    showStoryViewer = true
                                } else {
                                    // אם אין סטוריז, פשוט פותח את תהליך ההזמנה
                                    viewModel.selectedStaff = staff
                                    showBookingFlow = true
                                }
                            }
                        )
                    }
                }
                .padding(.horizontal, 20)
                .padding(.vertical, 8)
            }
        }
        .opacity(animateCarousel ? 1 : 0)
        .offset(y: animateCarousel ? 0 : 20)
        .onAppear {
            withAnimation(.easeOut(duration: 0.6).delay(0.2)) {
                animateCarousel = true
            }
        }
        .fullScreenCover(isPresented: $showStoryViewer) {
            if let staff = selectedStaff {
                StoryViewer(
                    staff: staff,
                    isPresented: $showStoryViewer,
                    onBookAppointment: {
                        showStoryViewer = false
                        viewModel.selectedStaff = staff
                        showBookingFlow = true
                    }
                )
            }
        }
    }
    
    private func hasValidStories(_ staff: Staff) -> Bool {
        staff.stories?.contains { $0.isValid } ?? false
    }
}

// MARK: - Story Circle (עיגול של ספר עם Stories)

struct StoryCircle: View {
    let staff: Staff
    let onTap: () -> Void
    
    private var hasNewStories: Bool {
        staff.stories?.contains { $0.isValid && !$0.isViewed } ?? false
    }
    
    private var hasStories: Bool {
        staff.stories?.contains { $0.isValid } ?? false
    }
    
    var body: some View {
        Button(action: onTap) {
            VStack(spacing: 8) {
                ZStack {
                    // טבעת צבעונית אם יש סטוריז חדשים
                    if hasNewStories {
                        Circle()
                            .stroke(
                                LinearGradient(
                                    gradient: Gradient(colors: [
                                        Color(hex: "FF6B6B"),
                                        Color(hex: "FFA06B"),
                                        Color(hex: "FFD06B")
                                    ]),
                                    startPoint: .topLeading,
                                    endPoint: .bottomTrailing
                                ),
                                lineWidth: 3
                            )
                            .frame(width: 82, height: 82)
                    } else if hasStories {
                        // טבעת אפורה אם כל הסטוריז נצפו
                        Circle()
                            .stroke(Color.gray.opacity(0.3), lineWidth: 3)
                            .frame(width: 82, height: 82)
                    }
                    
                    // תמונת הספר
                    Image(staff.imageName)
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .frame(width: 75, height: 75)
                        .clipShape(Circle())
                        .overlay(
                            Circle()
                                .stroke(Color.white, lineWidth: 3)
                        )
                        .shadow(color: Color.black.opacity(0.2), radius: 10, x: 0, y: 5)
                }
                
                Text(staff.name)
                    .font(.system(size: 13, weight: hasNewStories ? .semibold : .medium))
                    .foregroundColor(.black)
            }
        }
    }
}

// MARK: - Story Viewer (תצוגת סטוריז במסך מלא)

struct StoryViewer: View {
    let staff: Staff
    @Binding var isPresented: Bool
    let onBookAppointment: () -> Void
    
    @State private var currentIndex = 0
    @State private var progress: CGFloat = 0
    @State private var timer: Timer?
    
    private var validStories: [Story] {
        staff.stories?.filter { $0.isValid } ?? []
    }
    
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            
            if !validStories.isEmpty {
                // התמונה/וידאו הנוכחי
                currentStoryView
                
                // שכבת גרדיאנט עליונה
                VStack(spacing: 0) {
                    LinearGradient(
                        gradient: Gradient(colors: [
                            Color.black.opacity(0.6),
                            Color.clear
                        ]),
                        startPoint: .top,
                        endPoint: .bottom
                    )
                    .frame(height: 150)
                    
                    Spacer()
                    
                    // גרדיאנט תחתון
                    LinearGradient(
                        gradient: Gradient(colors: [
                            Color.clear,
                            Color.black.opacity(0.6)
                        ]),
                        startPoint: .top,
                        endPoint: .bottom
                    )
                    .frame(height: 200)
                }
                .ignoresSafeArea()
                
                // פסי התקדמות + כותרת
                VStack(spacing: 0) {
                    // פסי התקדמות
                    HStack(spacing: 4) {
                        ForEach(0..<validStories.count, id: \.self) { index in
                            GeometryReader { geometry in
                                ZStack(alignment: .leading) {
                                    // רקע
                                    Rectangle()
                                        .fill(Color.white.opacity(0.3))
                                    
                                    // התקדמות
                                    Rectangle()
                                        .fill(Color.white)
                                        .frame(width: index < currentIndex ? geometry.size.width : (index == currentIndex ? geometry.size.width * progress : 0))
                                }
                            }
                            .frame(height: 2)
                            .cornerRadius(1)
                        }
                    }
                    .padding(.horizontal, 12)
                    .padding(.top, 50)
                    
                    // פרטי הספר
                    HStack(spacing: 12) {
                        // תמונה
                        Image(staff.imageName)
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: 35, height: 35)
                            .clipShape(Circle())
                            .overlay(Circle().stroke(Color.white, lineWidth: 2))
                        
                        // שם + זמן
                        VStack(alignment: .leading, spacing: 2) {
                            Text(staff.name)
                                .font(.system(size: 15, weight: .semibold))
                                .foregroundColor(.white)
                            
                            Text(formatStoryTime(validStories[currentIndex].createdAt))
                                .font(.system(size: 12))
                                .foregroundColor(.white.opacity(0.7))
                        }
                        
                        Spacer()
                        
                        // כפתור סגירה
                        Button(action: {
                            isPresented = false
                        }) {
                            Image(systemName: "xmark")
                                .font(.system(size: 18, weight: .semibold))
                                .foregroundColor(.white)
                                .frame(width: 30, height: 30)
                        }
                    }
                    .padding(.horizontal, 16)
                    .padding(.top, 12)
                    
                    Spacer()
                    
                    // Caption אם קיים
                    if let caption = validStories[currentIndex].caption {
                        Text(caption)
                            .font(.system(size: 15))
                            .foregroundColor(.white)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, 20)
                            .padding(.bottom, 100)
                    }
                    
                    // כפתור הזמנת תור
                    Button(action: onBookAppointment) {
                        Text("קבע תור עם \(staff.name)")
                            .font(.system(size: 16, weight: .semibold))
                            .foregroundColor(.black)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 14)
                            .background(Color.white)
                            .cornerRadius(25)
                    }
                    .padding(.horizontal, 20)
                    .padding(.bottom, 40)
                }
                
                // אזורי לחיצה (ימין/שמאל) למעבר בין סטוריז
                HStack(spacing: 0) {
                    // אזור שמאל - סטורי הבא
                    Color.clear
                        .contentShape(Rectangle())
                        .onTapGesture {
                            nextStory()
                        }
                    
                    // אזור ימין - סטורי קודם
                    Color.clear
                        .contentShape(Rectangle())
                        .onTapGesture {
                            previousStory()
                        }
                }
            }
        }
        .onAppear {
            startTimer()
        }
        .onDisappear {
            stopTimer()
        }
    }
    
    private var currentStoryView: some View {
        Group {
            if validStories[currentIndex].mediaType == .image {
                // TODO: להשתמש ב-AsyncImage כשיהיה URL אמיתי
                // כרגע נשתמש בתמונה לוקלית
                Image(staff.imageName)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else {
                // TODO: להוסיף Video Player
                Text("Video Player")
                    .foregroundColor(.white)
            }
        }
    }
    
    private func startTimer() {
        timer = Timer.scheduledTimer(withTimeInterval: 0.05, repeats: true) { _ in
            if progress < 1 {
                progress += 0.01
            } else {
                nextStory()
            }
        }
    }
    
    private func stopTimer() {
        timer?.invalidate()
        timer = nil
    }
    
    private func nextStory() {
        if currentIndex < validStories.count - 1 {
            currentIndex += 1
            progress = 0
        } else {
            // סיימנו את כל הסטוריז
            isPresented = false
        }
    }
    
    private func previousStory() {
        if currentIndex > 0 {
            currentIndex -= 1
            progress = 0
        }
    }
    
    private func formatStoryTime(_ date: Date) -> String {
        let now = Date()
        let diff = now.timeIntervalSince(date)
        
        if diff < 60 {
            return "עכשיו"
        } else if diff < 3600 {
            let minutes = Int(diff / 60)
            return "לפני \(minutes) דק'"
        } else if diff < 86400 {
            let hours = Int(diff / 3600)
            return "לפני \(hours) שעות"
        } else if diff < 172800 { // פחות מיומיים
            return "אתמול"
        } else if diff < 604800 { // פחות משבוע
            let days = Int(diff / 86400)
            return "לפני \(days) ימים"
        } else if diff < 2592000 { // פחות מחודש
            let weeks = Int(diff / 604800)
            return weeks == 1 ? "לפני שבוע" : "לפני \(weeks) שבועות"
        } else {
            let months = Int(diff / 2592000)
            return months == 1 ? "לפני חודש" : "לפני \(months) חודשים"
        }
    }
}
